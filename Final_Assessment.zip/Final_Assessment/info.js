// Defining a function to display error message
function printError(elemId, hintMsg) {
    document.getElementById(elemId).innerHTML = hintMsg;
}

// Defining a function to validate form 
function validateForm() {
    // Retrieving the values of form elements 
    var f_name = document.signup.f_name.value;
    var l_name = document.signup.l_name.value;
    var password = document.signup.password.value;
    var username = document.signup.username.value;
    var education_level = document.signup.education_level.value;
    var education_status = document.signup.education_status.value;
    var email = document.signup.email.value;
    var age = document.signup.age.value;

    
	// Defining error variables with a default value
    var f_nameErr = l_nameErr = passwordErr = usernameErr = education_levelErr = education_statusErr = emailErr = ageErr = true;
    
    // Validate First name
    if(f_name == "") {
        printError("f_name", "Please enter your First name");
    } else {
        var regex = /^[a-zA-Z\s]+$/;                
        if(regex.test(f_name) === false) {
            printError("f_name", "Please enter a valid First name");
        } else {
            printError("f_name", "");
             f_nameErr = false;
        }
    }

    // Validate Last name
    if(l_name == "") {
        printError("l_name", "Please enter your  Last name");
    } else {
        var regex = /^[a-zA-Z\s]+$/;                
        if(regex.test(l_name) === false) {
            printError("l_name", "Please enter a valid Last name");
        } else {
            printError("l_name", "");
             l_nameErr = false;
        }
    }
    
	// Validate Password    
    var errors = [];
    if (password.length < 6) {
        errors.push("Your password must be at least 6 characters.<br>");
    }
    if (password.search(/[A-Z]/i) < 0) {
        errors.push("Your password must contain at least one uppercase letter.<br>"); 
    }
    if (password.search(/[0-9]/) < 0) {
        errors.push("Your password must contain at least one digit.<br>");
    }
    if (errors.length > 0) {
        // alert(errors.join("\n"));
         printError("password", errors.join("\n"));
    }else{
    	printError("password", "");
    	passwordErr = false;
    }
    
    // Validate Education Level
    if(education_level == "") {
        printError("education_level", "Please select your Education level");
    } else {
        printError("education_level", "");
        education_levelErr = false;
    }

    // Validate username
    if(username == "") {
        printError("username", "Please enter your Username");
    } else {
        var regex = /^[a-zA-Z0-9_]{5,}[a-zA-Z]+[0-9]*$/;                
        if(regex.test(username) === false) {
            printError("username", "Please enter a valid Username");
        } else {
            printError("username", "");
             usernameErr = false;
        }
    }

    // Validate email address
    if(email == "") {
        printError("email", "Please enter your email address");
    } else {
        // Regular expression for basic email validation
        var regex = /^\S+@\S+\.\S+$/;
        if(regex.test(email) === false) {
            printError("email", "Please enter a valid email address");
        } else{
            printError("email", "");
             emailErr = false;
        }
    }
    
	// Validate Education Status
    if(education_status == "") {
    	printError("education_status", "Please Select Your Education Status");
	}else{
    	printError("education_status", "");
		education_statusErr = false;
	}

   // Validate Age
   console.log(age >= 18 && age <= 60);
   if(age == "") {
        printError("age", "Please enter your age");
    } else {              
        if(age >= 18 && age <= 60) {
            printError("age", "");
            ageErr = false;
        } else {
            printError("age", "Please enter a valid age");
        }
    }

    // Prevent the form from being submitted if there are any errors
    if((f_nameErr || l_nameErr || passwordErr || usernameErr || education_levelErr || education_statusErr || emailErr || ageErr) == true) {
       return false;
    }
};